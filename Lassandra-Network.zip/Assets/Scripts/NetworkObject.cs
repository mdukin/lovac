﻿using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using UnityEngine;

public class NetworkObject : NetworkBehaviour
{

    public NetworkVariable<Vector3> objectPosition = new NetworkVariable<Vector3>();

    // Start is called before the first frame update
    void Start()
    {;
        objectPosition.OnValueChanged += OnPositionChanged;
        if (IsServer)
        {
            objectPosition.Value = transform.position;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (IsOwner)
        {
            UpdatePositionRpc(transform.position);
        }
    }

    private void OnPositionChanged(Vector3 oldPosition, Vector3 newPosition)
    {
        transform.position = newPosition;
    }

    [Rpc(SendTo.Everyone)]
    public void UpdatePositionRpc(Vector3 newPosition)
    {
        transform.position = newPosition;
    }
}
